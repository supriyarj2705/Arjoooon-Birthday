# Music Setup

Place your birthday music file here as:

**`music.mp3`**

The music will:

- Autoplay when the website loads (if browser allows)
- Loop continuously
- Can be paused/played using the toggle button in the top-right corner

## Tips:

- Use MP3 format for best browser compatibility
- Keep file size reasonable (under 10MB recommended)
- Test the volume before showing the website
